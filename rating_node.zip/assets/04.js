var store = require('app-store-scraper');
 
store.app({id: 553834731, ratings: true}).then(console.log).catch(console.log);