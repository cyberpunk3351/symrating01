
// const store = require('app-store-scraper');
//
// store.ratings({
//   appId: '553834731'
// })
//   .then(response => {
//     fs.writeFileSync('file.json', JSON.stringify(response));
//   })
//   .catch(err => {
//     fs.writeFileSync('file.json', JSON.stringify(err));
//   });

const fs = require('fs');
const store = require('app-store-scraper');

// let val01 = document.getElemetById("input").value;

store.search({
  term: 'ninja',
  num: 1,
  page: 1,
  country : 'us',
  lang: 'lang'
})
  .then(response => {
    fs.writeFileSync('file.json', JSON.stringify(response));
  })
  .catch(err => {
    fs.writeFileSync('file.json', JSON.stringify(err));
  });

